package enums

enum class TournamentType {
    SINGLEELIMINATION,
    DOUBLEELIMINATION
}