package models


class Player (var name: String) {

}