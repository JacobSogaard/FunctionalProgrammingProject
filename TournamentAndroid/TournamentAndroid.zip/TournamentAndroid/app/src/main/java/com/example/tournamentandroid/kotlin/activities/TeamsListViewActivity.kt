package org.jetbrains.kotlin.activities

import Adapters.TeamListAdapter
import android.annotation.SuppressLint
import android.content.Context
import android.content.SharedPreferences
import android.os.Bundle
import android.view.ContextMenu
import android.view.MenuItem
import android.view.View
import android.widget.AdapterView.AdapterContextMenuInfo
import android.widget.ListView
import androidx.appcompat.app.AppCompatActivity
import com.example.tournamentandroid.R
import models.Team


class TeamsListViewActivity : AppCompatActivity() {
    private lateinit var listView: ListView
    private lateinit var _adapter: TeamListAdapter
    private var PRIVATE_MODE = 0
    private val PREF_NAME = "tournament_app"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.team_list_view)
        listView = findViewById(R.id.teams_list)
        val listItems: ArrayList<Team> = intent?.extras?.get("Teams") as ArrayList<Team>
        //val t1 = Team("Team1", Player("Player1"), Player("Player2"))
        //val t2 = Team("Team1", Player("Player1"), Player("Player2"))
        //val listItems = listOf(t1, t2)
        _adapter = TeamListAdapter(this, listItems)
        listView.adapter = _adapter
        registerForContextMenu(listView)



    }

    override fun onBackPressed() {
        super.onBackPressed()
    }

    @SuppressLint("ResourceType")
    override fun onCreateContextMenu(menu: ContextMenu?, v: View?, menuInfo: ContextMenu.ContextMenuInfo?) {
        super.onCreateContextMenu(menu, v, menuInfo)
        val inflater = menuInflater
        inflater.inflate(R.layout.tournament_menu, menu)

    }

    override fun onContextItemSelected(item: MenuItem?): Boolean {
        if (item != null) {
            if (item.itemId == R.id.delete_menu_item) {
                val info = item.menuInfo as AdapterContextMenuInfo
                _adapter.deleteItem(info.position)
                _adapter.notifyDataSetChanged()
                return true
            }
        }
        return false
    }



}
