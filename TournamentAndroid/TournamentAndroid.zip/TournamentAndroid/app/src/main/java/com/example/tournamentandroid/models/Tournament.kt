package models


import enums.TournamentType
import kotlin.random.Random


class Tournament(type: TournamentType, var teams: List<Team>) {
    var games = mutableListOf<Game>()
    private var isRandom: Boolean? = null
    private var rnd: Random? = null
    private var currentRound =
        0
    private  var maxRounds:Int = 0
    private  var firstRoundMatches:Int = 0
    private  var cupLimit:Int = 0
    private var onGoingMatches: MutableList<Game>? = null
    private  var concludedMatches:MutableList<Game>? = null
    private var teamsPickedThisRound: MutableSet<Int>? = null


   init {
        isRandom = false
        //rnd = Random()
        currentRound = 1
        this.teams = ArrayList()
        onGoingMatches = ArrayList()
        this.concludedMatches = ArrayList()
        teamsPickedThisRound = HashSet()
    }



    fun getAllTeams(): List<Team?>? {
        return this.teams
    }


    /*
    fun setRandom(bool: Boolean) {
        if (bool) rnd = Random()
        isRandom = bool
    }

     */

    fun setCupLimit(limit: Int) {
        this.cupLimit = limit
    }

    fun getCupLimit(): Int {
        return this.cupLimit
    }

    fun getConcludedMatches(): List<Game?>? {
        return this.concludedMatches
    }

    fun start() {
        //Maybe change a boolean to be checked in fx addTeam and stuff, so that method is no longer doing anything
        val teams: Int = this.teams.size
        if (teams == 4) {
            this.maxRounds = 2
            this.firstRoundMatches = 2
        } else if (teams < 9) {
            this.maxRounds = 3
            this.firstRoundMatches = teams - 4
        } else if (teams < 17) {
            this.maxRounds = 4
            this.firstRoundMatches = teams - 8
        } else if (teams < 33) {
            this.maxRounds = 5
            this.firstRoundMatches = teams - 16
        }
        loadMatchesForRound()
    }

    fun getCurrentRound(): Int {
        return currentRound
    }

    fun getMaxRounds(): Int {
        return this.maxRounds
    }

    /**
     * Should be called after tournament has ended and before each call on
     * getMatchesForRound(int round).
     * @param round
     * @return
     */
    fun hasRound(round: Int): Boolean {
        return this.maxRounds >= round
    }

    /**
     * Should only be called if hasRound(int round) returns true
     * for the same round.
     * @param round
     * @return
     */
    fun getMathcesForRound(round: Int): List<Game>? {
        val theMatches: MutableList<Game> = ArrayList()
        for (m in this.concludedMatches!!) {
            if (m.getEndRound() === round) theMatches.add(m)
        }
        return theMatches
    }


    private fun loadMatchesForRound() {
        teamsPickedThisRound!!.clear()
        if (currentRound == 1) {
            for (i in 0 until this.firstRoundMatches) {
                onGoingMatches!!.add(Game(getNextTeam(), getNextTeam(), Random.nextInt(0, 100000)))
            }
        } else {
            for (i in 0 until this.teams.size / 2) {
                onGoingMatches!!.add(Game(getNextTeam(), getNextTeam(), Random.nextInt(0, 100000)))
            }
        }
    }

    private fun getNextTeam(): Team? {
        if (this.teams.isEmpty()) {
            return null
        }
        var index: Int
        do {
            index = Random.nextInt(this.teams.size)
        } while (teamsPickedThisRound!!.contains(index))
        teamsPickedThisRound!!.add(index)
        return this.teams.get(index)
    }

    fun getNextMatch(): Game? {
        return if (!onGoingMatches!!.isEmpty()) {
            onGoingMatches!![0]
        } else null
    }


    fun concludeMatch(match: Game) {
        //Update the match with the new score
        for (i in onGoingMatches!!.indices) {
            if (onGoingMatches!![i].id == match.id) {
                onGoingMatches!!.removeAt(i)
                this.concludedMatches?.add(match)
                this.teams.drop(teams.indexOf(match.getLoser()))
                println(
                    """
                        Round: ${currentRound}
                        Matches: ${this.concludedMatches?.size}
                        """.trimIndent()
                )
                break
            }
        }
        setWinner(match.getWinner())
    }

    fun setWinner(team: Team?) {
        if (onGoingMatches!!.isEmpty()) {
            currentRound++
            loadMatchesForRound()
        }
    }

}