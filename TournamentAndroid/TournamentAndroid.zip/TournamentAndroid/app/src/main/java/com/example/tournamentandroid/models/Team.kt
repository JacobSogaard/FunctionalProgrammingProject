package models



class Team (val teamName: String, val player1: Player = Player(""), val player2: Player = Player("")) {


    override fun toString(): String =  "t" + teamName + "p1" + player1.name + "p2" + player2.name
}