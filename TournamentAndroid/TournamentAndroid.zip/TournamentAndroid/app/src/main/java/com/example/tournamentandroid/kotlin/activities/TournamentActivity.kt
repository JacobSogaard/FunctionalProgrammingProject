package org.jetbrains.kotlin.activities


import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.tournamentandroid.R

class TournamentActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_tournament)
    }
}
